## 使用

开发

```js
npm run dev
```

开发并本地 mock API

```js
npm run dev:mock
```

生产打包

```js
npm run build
```
