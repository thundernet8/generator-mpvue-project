// 扩展app实例的方法和属性
export default {
    getName() {
        return this.name;
    }
};
