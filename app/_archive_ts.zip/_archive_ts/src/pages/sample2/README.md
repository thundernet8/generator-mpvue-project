## 说明

本页面使用 Vue Class 继承式组件写法

```js
export default class Sample2 extends Vue {
    // ...
}
```
