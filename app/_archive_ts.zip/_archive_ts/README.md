## 使用

开发

```js
npm run dev
```

开发并本地 mock API

```js
npm run dev:mock
```

生产打包

```js
npm run build
```

## @gfe/wxapp-common-vue

[@gfe/wxapp-common-vue](http://git.dianpingoa.com/v2/sh/projects/~WUXUEQIAN/repos/wxapp-common/browse)
