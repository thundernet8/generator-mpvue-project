## 使用

开发

```js
npm run dev
```

开发并本地 mock API

```js
npm run dev:mock
```

生产打包

```js
npm run build
```

快速添加新页面

```js
npm run newpage
```

## common-mpvue

[common-mpvue](https://github.com/thundernet8/common-mpvue)
